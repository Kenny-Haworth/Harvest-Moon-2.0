# Harvest Moon 2.0

CS 4700 Game Development Final Assignment

Group Members:
<ul>
  <li>Kendall Haworth</li>
  <li>Jordyn Sato</li>
  <li>Jeffrey Nguyen</li>
  <li>Serena Ing</li>
  <li>Anthony Nuno</li>
</ul>